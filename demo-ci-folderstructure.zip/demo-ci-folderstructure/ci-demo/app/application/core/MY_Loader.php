<?php if (!defined('BASEPATH'))
{
    exit('No direct script access allowed');
}

class MY_Loader extends CI_Loader
{
    function __construct()
    {
        parent::__construct();
    }
	
	function site_template($template_name, $vars = [], $result = true)
    {
        $content = [];
        $content['head_content'] = $this->view('default/header_view', $vars, $result);
        $content['body_content'] = $this->view($template_name, $vars, $result);
        $content['footer_content'] = $this->view('default/footer_view', $vars, $result);
       
        // $this->load_template($content);
        $CI =& get_instance();
        $CI->output->set_output($content['head_content'] . $content['body_content'] . $content['footer_content']);
    }
	
}