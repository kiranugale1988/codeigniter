<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TestController extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		//$this->load->view('welcome_message');
		$todo_list = array( 'milk', 'bread', 'eggs', 'sugar' );
        $data['title']        = 'Page Title';
        $data['main_content'] = 'welcome'; // "welcome" is the filename of your view
        $data['todo']          = $todo_list;
		
		$this->load->site_template('default/list',$data);
	}
}
